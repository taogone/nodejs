var calc = {};

calc.minus = function(a, b) {
  return a - b;
};

module.exports = calc;
