console.log("콘솔에 로그를 뿌려줌");
console.log("나이:%s 나이:%d", "김영기", 51);
console.log("성명:" + "김영기" + " 나이:" + 51);
var name = "김영기";
var age = 51;
console.log(`성명:${name} 나이:${age}`);

for (let i in [10, 20, 30, 40, 50]) {
  console.log(`i는 ${i}입니다.`);
}
